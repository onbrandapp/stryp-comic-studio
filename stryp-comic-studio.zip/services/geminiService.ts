
import { GoogleGenAI, Type, Modality, GenerateContentResponse } from "@google/genai";
import { Character, Panel } from '../types';

// Helper to wrap promises with a timeout
function withTimeout<T>(promise: Promise<T>, ms: number, errorMessage: string): Promise<T> {
  let timeoutId: any;
  const timeoutPromise = new Promise<T>((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(errorMessage)), ms);
  });
  
  return Promise.race([
    promise.then((res) => {
      clearTimeout(timeoutId);
      return res;
    }),
    timeoutPromise
  ]);
}

// Optimized helper to fetch image and convert to base64 with mime type
async function fetchImageAsBase64(url: string): Promise<{ mimeType: string; data: string }> {
  // Optimization: If it's already a data URI, parse it directly
  if (url.startsWith('data:')) {
    const commaIndex = url.indexOf(',');
    const header = url.substring(0, commaIndex);
    const mimeType = header.match(/:(.*?);/)?.[1] || 'image/png';
    const data = url.substring(commaIndex + 1);
    return { mimeType, data };
  }

  // WRAPPED IN TIMEOUT: Enforce strict 2s limit on the entire operation
  return withTimeout((async () => {
    const controller = new AbortController();
    // Internal signal timeout as backup
    const id = setTimeout(() => controller.abort(), 2000);

    try {
      const response = await fetch(url, { 
        credentials: 'omit', // Helps with CORS on some public buckets
        signal: controller.signal
      });
      clearTimeout(id);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const blob = await response.blob();
      
      // Convert blob to base64 manually to ensure we catch FileReader errors
      return await new Promise<{ mimeType: string; data: string }>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          if (!result) {
              reject(new Error("Empty result"));
              return;
          }
          const commaIndex = result.indexOf(',');
          if (commaIndex === -1) {
               reject(new Error("Invalid data"));
               return;
          }
          const header = result.substring(0, commaIndex);
          const base64 = result.substring(commaIndex + 1);
          const mimeType = header.match(/:(.*?);/)?.[1] || blob.type || 'image/png';
          resolve({ mimeType, data: base64 });
        };
        reader.onerror = () => reject(new Error("FileReader failed"));
        reader.readAsDataURL(blob);
      });

    } catch (error) {
      clearTimeout(id);
      throw error;
    }
  })(), 2500, "Image fetch timed out"); // 2.5s total buffer
}


class GeminiService {
  private getClient() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  // Generate a script (list of panels)
  async generateScript(
    sceneDescription: string,
    mood: string,
    characters: Character[],
    existingContext: string
  ): Promise<Partial<Panel>[]> {
    
    const characterContext = characters
      .map(c => `${c.name}: ${c.bio}`)
      .join('\n');

    const prompt = `
      Create a comic strip script.
      Context: ${existingContext}
      Scene Description: ${sceneDescription}
      Mood: ${mood}
      Characters available:
      ${characterContext}

      Output a JSON array of panels. Each panel must have:
      - "description": A detailed visual description for an image generator. Include camera angle, lighting, and character appearance.
      - "dialogue": The text spoken in the panel (or caption).
      - "characterName": The name of the character speaking (if any).
    `;

    try {
      const response = await this.getClient().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                dialogue: { type: Type.STRING },
                characterName: { type: Type.STRING },
              },
              required: ['description', 'dialogue']
            }
          }
        }
      });

      const data = JSON.parse(response.text || '[]');
      
      return data.map((item: any) => {
        const char = characters.find(c => c.name.toLowerCase() === item.characterName?.toLowerCase());
        return {
          description: item.description,
          dialogue: item.dialogue,
          characterId: char ? char.id : undefined,
        };
      });

    } catch (error) {
      console.error("Script generation failed:", error);
      throw error;
    }
  }

  // Generate an image for a panel
  async generatePanelImage(
    panelDescription: string,
    character?: Character
  ): Promise<string> {
    try {
      const parts: any[] = [];
      let usedReferenceImage = false;

      // 1. Try to fetch and include the character reference image
      if (character && character.imageUrl) {
        try {
          const { mimeType, data } = await fetchImageAsBase64(character.imageUrl);
          
          parts.push({
            inlineData: {
              mimeType: mimeType,
              data: data
            }
          });
          usedReferenceImage = true;
        } catch (imageError: any) {
          console.warn(`[GeminiService] Reference image fetch failed: ${imageError.message}. Falling back to text description.`);
          // IMPORTANT: We swallow the error and proceed with text generation.
          usedReferenceImage = false;
        }
      }

      // 2. Construct the prompt
      if (usedReferenceImage) {
        parts.push({
          text: `Generate a comic book panel. ${panelDescription}. Maintain the character's appearance from the image. High contrast, professional digital art.`
        });
      } else if (character) {
        // Fallback: detailed text prompt using the character's bio
        parts.push({
          text: `Character Reference: Name "${character.name}", Description: ${character.bio}. \n\nTask: Generate a comic book panel. ${panelDescription}. High contrast, professional digital art.`
        });
      } else {
        parts.push({
          text: `Generate a comic book panel. ${panelDescription}. High contrast, professional digital art.`
        });
      }

      // 3. Call Gemini with Timeout
      // Enforce 90s timeout on the AI generation itself.
      const response = await withTimeout<GenerateContentResponse>(
        this.getClient().models.generateContent({
          model: 'gemini-2.5-flash-image', 
          contents: { parts },
          config: {}
        }),
        90000,
        "AI Generation timed out (90s)"
      );

      // Find the image part
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          const mimeType = part.inlineData.mimeType || 'image/png';
          return `data:${mimeType};base64,${part.inlineData.data}`;
        }
      }
      throw new Error("No image data returned from API");

    } catch (error) {
      console.error("Image generation failed:", error);
      throw error;
    }
  }

  // Generate TTS audio
  async generateSpeech(text: string, voiceName: string = 'Puck'): Promise<string> {
    try {
      // Wrapped in timeout to prevent hanging if the API is slow
      const response = await withTimeout<GenerateContentResponse>(
        this.getClient().models.generateContent({
          model: 'gemini-2.5-flash-preview-tts',
          contents: { parts: [{ text }] },
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName }
              }
            }
          }
        }),
        20000, // 20s timeout for audio
        "Audio generation timed out"
      );

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) throw new Error("No audio generated");

      return `data:audio/wav;base64,${base64Audio}`; 

    } catch (error) {
      console.error("Speech generation failed:", error);
      throw error;
    }
  }
}

export const gemini = new GeminiService();
