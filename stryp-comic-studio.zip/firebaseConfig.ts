
export const firebaseConfig = {
  apiKey: "AIzaSyDmVftgiDM10clKt3Xc83s0k2RwhgJjFFs",
  authDomain: "stryp-comic-studio.firebaseapp.com",
  projectId: "stryp-comic-studio",
  storageBucket: "stryp-comic-studio.appspot.com",
  messagingSenderId: "411015674008",
  appId: "1:411015674008:web:addc8f0f5b6c9e91e638ed",
  measurementId: "G-QBKB3M3441"
};