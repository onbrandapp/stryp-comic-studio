

export type ComicMode = 'static' | 'video';

export interface Character {
  id: string;
  name: string;
  bio: string;
  imageUrl: string; // URL for the reference image
  voiceId?: string; // Prebuilt voice name (e.g., 'Puck', 'Kore')
}

export interface Panel {
  id: string;
  description: string; // Scene description used for generation
  dialogue: string;
  characterId?: string; // The character speaking (if any)
  imageUrl?: string; // Generated image base64 or URL
  audioUrl?: string; // Generated or recorded audio URL
  isGeneratingImage: boolean;
  isGeneratingAudio: boolean;
}

export interface Project {
  id: string;
  title: string;
  summary: string; // Context for AI
  mode: ComicMode;
  createdAt: number;
  panels: Panel[];
}

export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  CHARACTERS = 'CHARACTERS',
  STUDIO = 'STUDIO',
  SETTINGS = 'SETTINGS',
}

export interface AppSettings {
  defaultNarratorVoiceId: string;
}

export const AVAILABLE_VOICES = [
  { id: 'Puck', name: 'Puck (Male, Soft)' },
  { id: 'Charon', name: 'Charon (Male, Deep)' },
  { id: 'Kore', name: 'Kore (Female, Calm)' },
  { id: 'Fenrir', name: 'Fenrir (Male, Intense)' },
  { id: 'Zephyr', name: 'Zephyr (Female, Bright)' },
];